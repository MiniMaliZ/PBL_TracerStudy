<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\Alumni;
use Illuminate\Console\View\Components\Alert;
use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use Illuminate\Support\Facades\Validator;
use Yajra\DataTables\Facades\DataTables;    


class ImportController extends Controller
{
    public function index()
    {
        return view('import.index', [
            'title' => 'Import Data Alumni'
        ]);
    }
    public function list(Request $request)
{
    $alumni = Alumni::select(
        'nim',
        'nama_alumni',
        'prodi',
        'no_hp',
        'email'
    );

    $filter_prodi = $request->input('filter_prodi');
    if (!empty($filter_prodi)) {
        $alumni->where('prodi', $filter_prodi);
    }

    return DataTables::of($alumni)
        ->addIndexColumn()
        ->addColumn('aksi', function ($alumni) {
            $btn  = '<button onclick="modalAction(\''.url('/alumni/' . $alumni->nim . '/show_ajax').'\')" class="btn btn-info btn-sm">Detail</button> ';
            $btn .= '<button onclick="modalAction(\''.url('/alumni/' . $alumni->nim . '/edit_ajax').'\')" class="btn btn-warning btn-sm">Edit</button> ';
            $btn .= '<button onclick="modalAction(\''.url('/alumni/' . $alumni->nim . '/delete_ajax').'\')" class="btn btn-danger btn-sm">Hapus</button> ';
            return $btn;
        })
        ->rawColumns(['aksi'])
        ->make(true);
}

    public function import()
    {
        return view('import.index');
    }
    public function import_ajax(Request $request)
    {
        if ($request->ajax() || $request->wantsJson()) {
            $rules = [
                // validasi file harus xls atau xlsx, max 1MB 
                'file_barang' => ['required', 'mimes:xlsx', 'max:1024']
            ];

            $validator = Validator::make($request->all(), $rules);
            if ($validator->fails()) {
                return response()->json([
                    'status' => false,
                    'message' => 'Validasi Gagal',
                    'msgField' => $validator->errors()
                ]);
            }

            $file = $request->file('file_import');  // ambil file dari request 

            $reader = IOFactory::createReader('Xlsx');  // load reader file excel 
            $reader->setReadDataOnly(true);             // hanya membaca data 
            $spreadsheet = $reader->load($file->getRealPath()); // load file excel 
            $sheet = $spreadsheet->getActiveSheet();    // ambil sheet yang aktif 

            $data = $sheet->toArray(null, false, true, true);   // ambil data excel 

            $insert = [];
            if (count($data) > 1) { // jika data lebih dari 1 baris 
                foreach ($data as $baris => $value) {
                    if ($baris > 1) { // baris ke 1 adalah header, maka lewati 
                        $insert[] = [
                            'nim' => $value['A'],
                            'nama_alumni' => $value['B'],
                            'prodi' => $value['C'],
                            'no_hp' => $value['D'],
                            'email' => $value['E'],
                        ];
                    }
                }

                if (count($insert) > 0) {
                    // insert data ke database, jika data sudah ada, maka diabaikan 
                    Alumni::insertOrIgnore($insert);
                }

                return response()->json([
                    'status' => true,
                    'message' => 'Data berhasil diimport'
                ]);
            } else {
                return response()->json([
                    'status' => false,
                    'message' => 'Tidak ada data yang diimport'
                ]);
            }
        }
        return redirect('/');
    }
    public function export_excel()
    {
        // Ambil data alumni
        $alumni = Alumni::orderBy('prodi')->get();
    
        // Load library spreadsheet
        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();
    
        // Set header kolom
        $sheet->setCellValue('A1', 'No');
        $sheet->setCellValue('B1', 'NIM');
        $sheet->setCellValue('C1', 'Nama Alumni');
        $sheet->setCellValue('D1', 'Prodi');
        $sheet->setCellValue('E1', 'No HP');
        $sheet->setCellValue('F1', 'Email');
    
        $sheet->getStyle('A1:F1')->getFont()->setBold(true);
    
        $no = 1;
        $baris = 2;
    
        foreach ($alumni as $item) {
            $sheet->setCellValue('A' . $baris, $no++);
            $sheet->setCellValue('B' . $baris, $item->nim);
            $sheet->setCellValue('C' . $baris, $item->nama_alumni);
            $sheet->setCellValue('D' . $baris, $item->prodi);
            $sheet->setCellValue('E' . $baris, $item->no_hp);
            $sheet->setCellValue('F' . $baris, $item->email);
            $baris++;
        }
    
        foreach (range('A', 'F') as $col) {
            $sheet->getColumnDimension($col)->setAutoSize(true);
        }
    
        $sheet->setTitle('Data Alumni');
    
        $writer = IOFactory::createWriter($spreadsheet, 'Xlsx');
        $filename = 'Data Alumni ' . date('Y-m-d H-i-s') . '.xlsx';
    
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment;filename="' . $filename . '"');
        header('Cache-Control: max-age=0');
        header('Expires: Mon, 26 Jul 1997 05:00:00 GMT');
        header('Last-Modified: ' . gmdate('D, d M Y H:i:s') . ' GMT');
        header('Cache-Control: cache, must-revalidate');
        header('Pragma: public');
    
        $writer->save('php://output');
        exit;
    }
}
