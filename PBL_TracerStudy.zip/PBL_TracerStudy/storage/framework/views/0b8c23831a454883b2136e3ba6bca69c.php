<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title><?php echo $__env->yieldContent('title', 'Dashboard'); ?></title>
    <!-- Fonts and icons -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Inter:300,400,500,600,700,900" />
    <link href="<?php echo e(asset('material-dashboard-master/assets/css/nucleo-icons.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('material-dashboard-master/assets/css/nucleo-svg.css')); ?>" rel="stylesheet" />
    <script src="https://kit.fontawesome.com/42d5adcbca.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded:opsz,wght,FILL,GRAD@24,400,0,0" />
    <link href="<?php echo e(asset('material-dashboard-master/assets/css/material-dashboard.css?v=3.2.0')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('material-dashboard-master/assets/css/custom.css')); ?>" rel="stylesheet" />

</head>

<body class="g-sidenav-show bg-gray-100">
    <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <main class="main-content position-relative max-height-vh-100 h-100 border-radius-lg">
        <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="container-fluid py-4">
            <?php echo $__env->yieldContent('content'); ?>
        </div>

        <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </main>

    <script src="<?php echo e(asset('material-dashboard-master/assets/js/core/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('material-dashboard-master/assets/js/core/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('material-dashboard-master/assets/js/plugins/perfect-scrollbar.min.js')); ?>"></script>
    <script src="<?php echo e(asset('material-dashboard-master/assets/js/plugins/smooth-scrollbar.min.js')); ?>"></script>
    <script src="<?php echo e(asset('material-dashboard-master/assets/js/material-dashboard.min.js?v=3.2.0')); ?>"></script>
    <script src="<?php echo e(asset('material-dashboard-master/assets/js/plugins/chartjs.min.js')); ?>"></script>

    <?php echo $__env->yieldContent('scripts'); ?>
</body>

</html><?php /**PATH C:\xampp\htdocs\PBL\PBL_TracerStudy\PBL_TracerStudy\resources\views/layouts/template.blade.php ENDPATH**/ ?>