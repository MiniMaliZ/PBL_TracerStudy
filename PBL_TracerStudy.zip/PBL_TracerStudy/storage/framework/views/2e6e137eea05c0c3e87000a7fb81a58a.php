


<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <h3 class="card-title">Daftar Alumni</h3>
        <div class="card-tools">
            <button onclick="modalAction('<?php echo e(url('/alumni/import')); ?>')" class="btn btn-info">Import Alumni</button>
            <a href="<?php echo e(url('/alumni/export_excel')); ?>" class="btn btn-primary"><i class="fa fa-file-excel"></i> Export Excel</a>
        </div>
    </div>
    <div class="card-body">
        
        <?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
        <?php endif; ?>

        <table class="table table-bordered table-sm table-striped table-hover" id="table-alumni">
            <thead>
                <tr>
                    <th>No</th>
                    <th>NIM</th>
                    <th>Nama Alumni</th>
                    <th>Prodi</th>
                    <th>No HP</th>
                    <th>Email</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody></tbody>
        </table>
    </div>
</div>

<div id="myModal" class="modal fade animate shake" tabindex="-1" data-backdrop="static" data-keyboard="false" data-width="75%"></div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script>
    function modalAction(url = '') {
        $('#myModal').load(url, function () {
            $('#myModal').modal('show');
        });
    }

    var tableAlumni;
    $(document).ready(function () {
        tableAlumni = $('#table-alumni').DataTable({
            processing: true,
            serverSide: true,
            ajax: {
                url: "<?php echo e(url('alumni/list')); ?>",
                type: "POST",
            },
            columns: [
                {
                    data: "DT_RowIndex",
                    className: "text-center",
                    width: "5%",
                    orderable: false,
                    searchable: false
                },
                { data: "nim", width: "15%" },
                { data: "nama_alumni", width: "25%" },
                { data: "prodi", width: "20%" },
                { data: "no_hp", width: "15%" },
                { data: "email", width: "20%" },
                {
                    data: "aksi",
                    className: "text-center",
                    width: "10%",
                    orderable: false,
                    searchable: false
                }
            ]
        });

        $('#table-alumni_filter input').unbind().bind().on('keyup', function (e) {
            if (e.keyCode == 13) {
                tableAlumni.search(this.value).draw();
            }
        });
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PBL\PBL_TracerStudy\PBL_TracerStudy\resources\views/import/index.blade.php ENDPATH**/ ?>